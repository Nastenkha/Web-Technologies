// File: FileReadWrite.java
import java.io.*;

public class FileReadWrite {
    public static void main(String[] args) {
        try {
            // ---------- Writing to a file ----------
            FileWriter writer = new FileWriter("example.txt");
            writer.write("Hello Sujitha!\n");
            writer.write("This is a simple file write and read example.");
            writer.close();
            System.out.println("Data written to file successfully.");

            // ---------- Reading from the file ----------
            FileReader reader = new FileReader("example.txt");
            int ch;
            System.out.println("\nReading data from file:");
            while ((ch = reader.read()) != -1) { // -1 means end of file
                System.out.print((char) ch);
            }
            reader.close();

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
