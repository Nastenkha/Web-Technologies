import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class counterservlet extends HttpServlet {
    private static int visits = 0;

    public void doGet(HttpServletRequest req, HttpServletResponse res) 
        throws ServletException, IOException {
        
        visits++;
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html><head><title> Example program for Ajax </title>");
        out.println("<script type='text/javascript' src='countupdate.js'></script>");
        out.println("</head><body onload='init()'>");
        out.println("<p>Welcome to the world :<br> Number of visits: <p id='visits'>0</p></body></html>");
        out.close();
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) 
        throws ServletException, IOException {
        
        res.setContentType("application/xml");
        PrintWriter out = res.getWriter();
        out.println("<?xml version='1.0'?><count>" + visits + "</count>");
        out.close();
    }
}
