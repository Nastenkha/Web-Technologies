import java.util.Random;

// Thread 1: Generates random numbers
class RandomNumberThread extends Thread {
    public void run() {
        Random rand = new Random();

        for (int i = 0; i < 5; i++) { // run 5 times for demo
            int num = rand.nextInt(100); // random number between 0 and 99
            System.out.println("Generated Number: " + num);

            if (num % 2 == 0) {
                new SquareThread(num).start();
            } else {
                new CubeThread(num).start();
            }

            try {
                Thread.sleep(1000); // wait for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

// Thread 2: Computes square
class SquareThread extends Thread {
    private int number;

    SquareThread(int number) {
        this.number = number;
    }

    public void run() {
        System.out.println("Square of " + number + " is " + (number * number));
    }
}

// Thread 3: Computes cube
class CubeThread extends Thread {
    private int number;

    CubeThread(int number) {
        this.number = number;
    }

    public void run() {
        System.out.println("Cube of " + number + " is " + (number * number * number));
    }
}

// Main class
public class MultiThreadedApp {
    public static void main(String[] args) {
        RandomNumberThread t1 = new RandomNumberThread();
        t1.start();
    }
}
