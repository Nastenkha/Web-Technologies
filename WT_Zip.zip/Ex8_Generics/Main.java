import java.util.Scanner;

class GenericCompare {
    // Method for same-type comparison
    public static <T extends Comparable<T>> boolean isEqual(T val1, T val2) {
        if (val1 == null && val2 == null) return true;
        if (val1 == null || val2 == null) return false;
        return val1.compareTo(val2) == 0;
    }

    // Method for mixed-type comparison
    public static <T, U> boolean isEqualMixed(T val1, U val2) {
        if (val1 == null && val2 == null) return true;
        if (val1 == null || val2 == null) return false;
        return val1.toString().equals(val2.toString());
    }
}

class Person implements Comparable<Person> {
    String name;
    Person(String name) {
        this.name = name;
    }
    @Override
    public int compareTo(Person other) {
        return this.name.compareTo(other.name);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Integer Comparison
        System.out.print("Enter first integer: ");
        Integer int1 = sc.nextInt();
        System.out.print("Enter second integer: ");
        Integer int2 = sc.nextInt();
        System.out.println("Integer Comparison: " + GenericCompare.isEqual(int1, int2));

        // Double Comparison
        System.out.print("Enter first double: ");
        Double d1 = sc.nextDouble();
        System.out.print("Enter second double: ");
        Double d2 = sc.nextDouble();
        System.out.println("Double Comparison: " + GenericCompare.isEqual(d1, d2));

        sc.nextLine(); // clear buffer

        // String Comparison
        System.out.print("Enter first string: ");
        String s1 = sc.nextLine();
        System.out.print("Enter second string: ");
        String s2 = sc.nextLine();
        System.out.println("String Comparison: " + GenericCompare.isEqual(s1, s2));

        // Mixed Type Comparison
        System.out.print("Enter integer for mixed type comparison: ");
        Integer mixInt = sc.nextInt();
        System.out.print("Enter double for mixed type comparison: ");
        Double mixDouble = sc.nextDouble();
        System.out.println("Mixed Type Comparison: " + GenericCompare.isEqualMixed(mixInt, mixDouble));

        sc.nextLine(); // clear buffer

        // Null Comparison
        System.out.println("Null Comparison (null, null): " + GenericCompare.isEqual(null, null));

        // Custom Object Comparison
        System.out.print("Enter name for Person 1: ");
        String pName1 = sc.nextLine();
        System.out.print("Enter name for Person 2: ");
        String pName2 = sc.nextLine();
        Person p1 = new Person(pName1);
        Person p2 = new Person(pName2);
        System.out.println("Custom Object Comparison: " + GenericCompare.isEqual(p1, p2));

        sc.close();
    }
}
