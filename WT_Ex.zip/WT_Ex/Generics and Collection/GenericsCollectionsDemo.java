// File: GenericsCollectionsDemo.java
import java.util.*;

// Generic class
class Box<T> {
    private T item;

    public Box(T item) {
        this.item = item;
    }

    public T getItem() {
        return item;
    }

    public void display() {
        System.out.println("Item: " + item);
    }
}

public class GenericsCollectionsDemo {
    public static void main(String[] args) {

        // Using Generic class with String type
        Box<String> box1 = new Box<>("Java Programming");
        Box<String> box2 = new Box<>("Python Programming");
        Box<String> box3 = new Box<>("C++ Programming");

        // Using Collection (ArrayList) to store generic objects
        ArrayList<Box<String>> bookList = new ArrayList<>();
        bookList.add(box1);
        bookList.add(box2);
        bookList.add(box3);

        // Display all elements in the list
        System.out.println("Books in the Collection:");
        for (Box<String> book : bookList) {
            book.display();
        }

        // Using another Collection - HashSet
        HashSet<Integer> numbers = new HashSet<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        numbers.add(10); // duplicate won't be added

        System.out.println("\nNumbers in the HashSet:");
        for (Integer num : numbers) {
            System.out.println(num);
        }
    }
}
