// userform.js — replaces JSF bean logic using localStorage
(function(){
  const nameEl = () => document.getElementById("username");
  const mailEl = () => document.getElementById("email");
  const greetEl = () => document.getElementById("greet");
  const formCard = () => document.getElementById("formCard");
  const respCard = () => document.getElementById("responseCard");

  function submit() {
    const user = nameEl().value.trim();
    const email = mailEl().value.trim();
    if(!user || !email){ alert("Please fill all fields."); return; }

    // store locally to mimic DB insert
    const records = JSON.parse(localStorage.getItem("users")||"[]");
    records.push({user,email,date:new Date().toISOString()});
    localStorage.setItem("users", JSON.stringify(records));

    // show response
    greetEl().textContent = `Hello ${user}`;
    formCard().style.display="none";
    respCard().style.display="block";
  }

  window.resetForm = () => {
    nameEl().value = ""; mailEl().value = "";
    formCard().style.display="block";
    respCard().style.display="none";
  };

  document.addEventListener("DOMContentLoaded",()=>{
    document.getElementById("submitBtn").addEventListener("click", submit);
  });
})();
