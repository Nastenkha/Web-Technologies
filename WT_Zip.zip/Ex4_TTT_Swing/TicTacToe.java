import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe extends JFrame implements ActionListener {
    private JButton[][] buttons = new JButton[3][3];
    private char currentPlayer = 'X';
    private boolean gameEnded = false;
    private JLabel statusLabel;
    private JButton resetButton;
    private JTextField player1Field, player2Field;
    private String playerX = "Player X", playerO = "Player O";

    public TicTacToe() {
        setTitle("Tic Tac Toe Game");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Player input panel
        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
        inputPanel.add(new JLabel("Player X Name:"));
        player1Field = new JTextField();
        inputPanel.add(player1Field);
        inputPanel.add(new JLabel("Player O Name:"));
        player2Field = new JTextField();
        inputPanel.add(player2Field);
        add(inputPanel, BorderLayout.NORTH);

        // Game board panel
        JPanel boardPanel = new JPanel(new GridLayout(3, 3));
        Font font = new Font("Arial", Font.BOLD, 40);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton("");
                buttons[i][j].setFont(font);
                buttons[i][j].addActionListener(this);
                boardPanel.add(buttons[i][j]);
            }
        }
        add(boardPanel, BorderLayout.CENTER);

        // Status and reset panel
        JPanel controlPanel = new JPanel(new GridLayout(2, 1));
        statusLabel = new JLabel("Click Reset to Start the Game", SwingConstants.CENTER);
        resetButton = new JButton("Reset Game");
        resetButton.addActionListener(e -> resetGame());
        controlPanel.add(statusLabel);
        controlPanel.add(resetButton);
        add(controlPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameEnded) return;

        JButton clicked = (JButton) e.getSource();
        if (!clicked.getText().equals("")) return;

        clicked.setText(String.valueOf(currentPlayer));

        if (checkWin()) {
            statusLabel.setText((currentPlayer == 'X' ? playerX : playerO) + " Wins!");
            gameEnded = true;
        } else if (isBoardFull()) {
            statusLabel.setText("It's a Draw!");
            gameEnded = true;
        } else {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            statusLabel.setText("Turn: " + (currentPlayer == 'X' ? playerX : playerO));
        }
    }

    private boolean checkWin() {
        // Rows, columns and diagonals
        for (int i = 0; i < 3; i++) {
            if (checkEqual(buttons[i][0], buttons[i][1], buttons[i][2])) return true;
            if (checkEqual(buttons[0][i], buttons[1][i], buttons[2][i])) return true;
        }
        return checkEqual(buttons[0][0], buttons[1][1], buttons[2][2]) ||
               checkEqual(buttons[0][2], buttons[1][1], buttons[2][0]);
    }

    private boolean checkEqual(JButton b1, JButton b2, JButton b3) {
        return !b1.getText().equals("") &&
               b1.getText().equals(b2.getText()) &&
               b2.getText().equals(b3.getText());
    }

    private boolean isBoardFull() {
        for (JButton[] row : buttons)
            for (JButton button : row)
                if (button.getText().equals("")) return false;
        return true;
    }

    private void resetGame() {
        // Validate names
        String name1 = player1Field.getText().trim();
        String name2 = player2Field.getText().trim();

        if (name1.isEmpty() || name2.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both player names.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        playerX = name1;
        playerO = name2;

        for (JButton[] row : buttons)
            for (JButton button : row)
                button.setText("");

        currentPlayer = 'X';
        gameEnded = false;
        statusLabel.setText("Turn: " + playerX);
    }

    public static void main(String[] args) {
        new TicTacToe();
    }
}
