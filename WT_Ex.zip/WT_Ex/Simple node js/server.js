// Import the http module
var http = require('http');

// Create a server
var server = http.createServer(function (request, response) {
    response.writeHead(200, { "Content-Type": "text/plain" });
    response.end("Hello World\n");
});

// Server listens on port 7000
server.listen(7000);

console.log("Server running at http://localhost:7000");

// Extra: using 'request' package to fetch Google
var request = require("request");
request("http://www.google.com", function (error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log("Google homepage fetched successfully!");
    }
});
