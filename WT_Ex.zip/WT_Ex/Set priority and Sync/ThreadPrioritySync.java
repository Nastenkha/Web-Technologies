// File: ThreadPrioritySync.java

class Table {
    // synchronized method to prevent multiple threads from accessing at the same time
    synchronized void printTable(int n) {
        for (int i = 1; i <= 5; i++) {
            System.out.println(n + " x " + i + " = " + (n * i));
            try {
                Thread.sleep(500); // pause for better observation
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

// Thread 1
class ThreadOne extends Thread {
    Table t;

    ThreadOne(Table t) {
        this.t = t;
    }

    public void run() {
        t.printTable(5);
    }
}

// Thread 2
class ThreadTwo extends Thread {
    Table t;

    ThreadTwo(Table t) {
        this.t = t;
    }

    public void run() {
        t.printTable(10);
    }
}

// Main class
public class ThreadPrioritySync {
    public static void main(String[] args) {
        Table obj = new Table(); // shared object

        ThreadOne t1 = new ThreadOne(obj);
        ThreadTwo t2 = new ThreadTwo(obj);

        // Setting priorities
        t1.setPriority(Thread.MIN_PRIORITY); // priority 1
        t2.setPriority(Thread.MAX_PRIORITY); // priority 10

        // Displaying priorities
        System.out.println("Thread 1 Priority: " + t1.getPriority());
        System.out.println("Thread 2 Priority: " + t2.getPriority());

        // Starting threads
        t1.start();
        t2.start();
    }
}
