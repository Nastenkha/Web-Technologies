import java.sql.*;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.RequestScoped;

@ManagedBean(name="user")
@RequestScoped
public class UserBean {
    private String userName;
    private String email;

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String submit() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/Emp", "root", "mysql");

            PreparedStatement ps = con.prepareStatement(
                "insert into user(name, email) values(?,?)");
            ps.setString(1, this.userName);
            ps.setString(2, this.email);
            ps.executeUpdate();

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            return "index.xhtml";  // if error → go back to form
        }
        return "response.xhtml";   // success → go to response page
    }
}
