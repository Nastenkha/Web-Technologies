import java.io.*;
import java.util.*;

class Employee {
    private String name;
    private String empId;
    private String department;
    private double salary;

    public Employee(String name, String empId, String department, double salary) {
        this.name = name;
        this.empId = empId;
        this.department = department;
        this.salary = salary;
    }

    public String getEmpId() {
        return empId;
    }

    public String toCSV() {
        return name + "," + empId + "," + department + "," + salary;
    }

    public static Employee fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        return new Employee(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]));
    }

    @Override
    public String toString() {
        return "Name: " + name + ", ID: " + empId + ", Dept: " + department + ", Salary: " + salary;
    }
}

class FileManager {
    private File file;

    public FileManager(String fileName) {
        file = new File(fileName);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }

    public void addEmployee(Employee emp) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(emp.toCSV());
            writer.newLine();
            System.out.println("Employee record added successfully!");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }
    }

    public void viewAllEmployees() {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            boolean empty = true;
            while ((line = reader.readLine()) != null) {
                Employee emp = Employee.fromCSV(line);
                System.out.println(emp);
                empty = false;
            }
            if (empty) {
                System.out.println("No records found.");
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }

    public void updateEmployee(String empId, Employee newEmp) {
        List<Employee> employees = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Employee emp = Employee.fromCSV(line);
                if (emp.getEmpId().equals(empId)) {
                    employees.add(newEmp);
                    found = true;
                } else {
                    employees.add(emp);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Employee emp : employees) {
                writer.write(emp.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing file.");
        }

        if (found) {
            System.out.println("Employee record updated successfully!");
        } else {
            System.out.println("Employee ID not found.");
        }
    }

    public void deleteEmployee(String empId) {
        List<Employee> employees = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Employee emp = Employee.fromCSV(line);
                if (!emp.getEmpId().equals(empId)) {
                    employees.add(emp);
                } else {
                    found = true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Employee emp : employees) {
                writer.write(emp.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing file.");
        }

        if (found) {
            System.out.println("Employee record deleted successfully!");
        } else {
            System.out.println("Employee ID not found.");
        }
    }
}

public class EmployeeRecordsSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FileManager manager = new FileManager("employees.csv");

        while (true) {
            System.out.println("\nEmployee Records Management System");
            System.out.println("1. Add New Employee Record");
            System.out.println("2. Update Employee Record");
            System.out.println("3. Delete Employee Record");
            System.out.println("4. View All Employee Records");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Employee ID: ");
                    String id = sc.nextLine();
                    System.out.print("Department: ");
                    String dept = sc.nextLine();
                    System.out.print("Salary: ");
                    double salary = sc.nextDouble();
                    manager.addEmployee(new Employee(name, id, dept, salary));
                    break;

                case 2:
                    System.out.print("Enter Employee ID to update: ");
                    String updateId = sc.nextLine();
                    System.out.print("New Name: ");
                    String newName = sc.nextLine();
                    System.out.print("New Department: ");
                    String newDept = sc.nextLine();
                    System.out.print("New Salary: ");
                    double newSalary = sc.nextDouble();
                    manager.updateEmployee(updateId, new Employee(newName, updateId, newDept, newSalary));
                    break;

                case 3:
                    System.out.print("Enter Employee ID to delete: ");
                    String deleteId = sc.nextLine();
                    manager.deleteEmployee(deleteId);
                    break;

                case 4:
                    manager.viewAllEmployees();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
