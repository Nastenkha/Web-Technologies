// EX.NO: 6
// AIM: JAVA THREADS – Set Priority and Synchronize Threads

import java.util.*;

class Order {
    String customerName;
    String restaurantName;
    String dish;
    String status;

    public Order(String customerName, String restaurantName, String dish) {
        this.customerName = customerName;
        this.restaurantName = restaurantName;
        this.dish = dish;
        this.status = "Pending";
    }
}

class Restaurant {
    String name;
    List<String> menu;

    public Restaurant(String name, List<String> menu) {
        this.name = name;
        this.menu = menu;
    }

    // synchronized ensures only one thread can process an order at a time
    public synchronized void processOrder(Order order) {
        order.status = "In progress";
        System.out.println(order.customerName + " placed order: " + order.dish + " from " + name);
        try {
            Thread.sleep(1000); // simulate cooking time
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        order.status = "Completed";
    }
}

class Customer extends Thread {
    Restaurant restaurant;
    String customerName;
    String dish;
    List<Order> globalOrderList;

    public Customer(String customerName, Restaurant restaurant, String dish, List<Order> globalOrderList) {
        this.customerName = customerName;
        this.restaurant = restaurant;
        this.dish = dish;
        this.globalOrderList = globalOrderList;
    }

    @Override
    public void run() {
        Order order = new Order(customerName, restaurant.name, dish);
        globalOrderList.add(order);
        restaurant.processOrder(order);
    }
}

public class OnlineFoodOrderingSystem {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("--- Online Food Ordering System ---\n");

        // Create Restaurants
        Restaurant mcDonalds = new Restaurant("McDonald's", Arrays.asList("Burger", "Nuggets", "Fries"));
        Restaurant pizzaHut = new Restaurant("Pizza Hut", Arrays.asList("Pizza", "Pasta", "Garlic Bread"));
        Restaurant subway = new Restaurant("Subway", Arrays.asList("Sub", "Salad", "Wrap"));

        List<Order> allOrders = Collections.synchronizedList(new ArrayList<>());

        // Create Customer threads
        Customer c1 = new Customer("John", mcDonalds, "Burger", allOrders);
        Customer c2 = new Customer("Alice", pizzaHut, "Pizza", allOrders);
        Customer c3 = new Customer("Bob", subway, "Sub", allOrders);
        Customer c4 = new Customer("Emily", mcDonalds, "Nuggets", allOrders);
        Customer c5 = new Customer("Sam", pizzaHut, "Pasta", allOrders);

        // Set Thread Priority
        c1.setPriority(Thread.MAX_PRIORITY);
        c2.setPriority(Thread.NORM_PRIORITY);
        c3.setPriority(Thread.MIN_PRIORITY);
        c4.setPriority(Thread.NORM_PRIORITY + 1);
        c5.setPriority(Thread.NORM_PRIORITY - 1);

        // Customer Orders table
        System.out.println("Available Restaurants:\n1. McDonald's\n2. Pizza Hut\n3. Subway\n");
        System.out.println("Customer Orders:");
        System.out.println("-------------------------------------------");
        System.out.println("| Customer | Restaurant   | Dish         |");
        System.out.println("-------------------------------------------");
        System.out.println("| John     | McDonald's   | Burger       |");
        System.out.println("| Alice    | Pizza Hut    | Pizza        |");
        System.out.println("| Bob      | Subway       | Sub          |");
        System.out.println("| Emily    | McDonald's   | Nuggets      |");
        System.out.println("| Sam      | Pizza Hut    | Pasta        |");
        System.out.println("-------------------------------------------");

        // Initial Order Status table (Pending)
        System.out.println("\nOrder Status:");
        System.out.println("-----------------------------------------------");
        System.out.println("| Customer | Restaurant   | Dish     | Status   |");
        System.out.println("-----------------------------------------------");
        System.out.println("| John     | McDonald's   | Burger   | Pending  |");
        System.out.println("| Alice    | Pizza Hut    | Pizza    | Pending  |");
        System.out.println("| Bob      | Subway       | Sub      | Pending  |");
        System.out.println("| Emily    | McDonald's   | Nuggets  | Pending  |");
        System.out.println("| Sam      | Pizza Hut    | Pasta    | Pending  |");
        System.out.println("-----------------------------------------------");

        // Start threads (process orders)
        c1.start();
        c2.start();
        c3.start();
        c4.start();
        c5.start();

        // Wait for all to finish
        c1.join();
        c2.join();
        c3.join();
        c4.join();
        c5.join();

        // Final Order Status table
        System.out.println("\nOrder Status After Processing:");
        System.out.println("-----------------------------------------------");
        System.out.println("| Customer | Restaurant   | Dish     | Status   |");
        System.out.println("-----------------------------------------------");
        for (Order order : allOrders) {
            System.out.printf("| %-8s | %-12s | %-8s | %-9s |\n",
                    order.customerName, order.restaurantName, order.dish, order.status);
        }
        System.out.println("-----------------------------------------------");
    }
}
