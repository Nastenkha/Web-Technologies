
function formValidator() {
  var fname = document.getElementById("fname").value;
  var lname = document.getElementById("lname").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  var phone = document.getElementById("phone").value;
  var checkbox = document.getElementById("terms").checked;

  if (fname === "" || fname.length < 6 || !/^[a-zA-Z]+$/.test(fname)) {
    alert("First Name must be at least 6 characters and contain only alphabets.");
    return false;
  }

  if (lname === "") {
    alert("Last Name is required.");
    return false;
  }

  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Invalid Email format.");
    return false;
  }

  if (password.length < 6) {
    alert("Password must be at least 6 characters long.");
    return false;
  }

  if (password !== confirmPassword) {
    alert("Passwords do not match.");
    return false;
  }

  if (!/^\d{10}$/.test(phone)) {
    alert("Phone number must be exactly 10 digits.");
    return false;
  }

  if (!checkbox) {
    alert("You must accept the terms and conditions.");
    return false;
  }

  alert("Form submitted successfully!");
  return true;
}
