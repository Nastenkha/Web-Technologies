import java.util.*;
import java.text.SimpleDateFormat;

class BankAccount {
    private int id;
    private int balance;

    public BankAccount(int id, int balance) {
        this.id = id;
        this.balance = balance;
    }

    public synchronized void deposit(int amount) {
        balance += amount;
        logTransaction("Deposit", amount);
    }

    public synchronized void withdraw(int amount) {
        if (balance >= amount) {
            balance -= amount;
            logTransaction("Withdraw", amount);
        } else {
            System.out.println(getTimeStamp() + " | Failed Withdrawal | $" + amount + " | Account " + id + " | Insufficient funds");
        }
    }

    public synchronized int getBalance() {
        return balance;
    }

    public int getId() {
        return id;
    }

    private void logTransaction(String type, int amount) {
        System.out.printf("| %s | %s | $%d | %d |\n", getTimeStamp(), type, amount, id);
    }

    private String getTimeStamp() {
        return new SimpleDateFormat("HH:mm:ss").format(new Date());
    }
}

class Transaction extends Thread {
    private BankAccount account;
    private String type;
    private int amount;
    private int delaySeconds;

    public Transaction(BankAccount account, String type, int amount, int delaySeconds) {
        this.account = account;
        this.type = type;
        this.amount = amount;
        this.delaySeconds = delaySeconds;
    }

    public void run() {
        try {
            Thread.sleep(delaySeconds * 1000L);  // Unique delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (type.equalsIgnoreCase("Deposit")) {
            account.deposit(amount);
        } else if (type.equalsIgnoreCase("Withdraw")) {
            account.withdraw(amount);
        }
    }
}

public class BankSimulation {
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount(1, 1000);
        BankAccount account2 = new BankAccount(2, 2000);

        System.out.println("Bank Transactions Simulation ---");
        System.out.println("\nInitial Balances:");
        System.out.println("Account 1: $" + account1.getBalance());
        System.out.println("Account 2: $" + account2.getBalance());

        System.out.println("\nTransaction Log:");
        System.out.println("| Timestamp | Type     | Amount | Account |");

        // Assigning delay to guarantee different timestamps (in seconds)
        Transaction[] transactions = {
            new Transaction(account1, "Deposit", 500, 1),
            new Transaction(account2, "Withdraw", 200, 2),
            new Transaction(account1, "Deposit", 100, 3),
            new Transaction(account1, "Withdraw", 300, 4),
            new Transaction(account2, "Deposit", 700, 5),
            new Transaction(account2, "Withdraw", 1000, 6)
        };

        for (Transaction t : transactions) {
            t.start();
        }

        for (Transaction t : transactions) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("\nFinal Balances:");
        System.out.println("Account 1: $" + account1.getBalance());
        System.out.println("Account 2: $" + account2.getBalance());
    }
}
