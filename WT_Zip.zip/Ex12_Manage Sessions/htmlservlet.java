import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class hello extends HttpServlet
{
private int visits=0;
public void doGet(HttpServletRequestreq, HttpServletResponse res) throws ServletException, IOException 

Print nt Writersrout-res.getWriter();
visits++;
String username req.getParameter("usertxt");
String password=req.getParameter("passwordtxt");

if ((username equals("administrator")) && (password squab("sam")))
srout println(“<html><head><title> Hello</title></head><body><h1>hello world</h1><h4>Number of visits:”+visits+”</h4>\n</b></p></body><html>”);

else srout println(“<html><head><title>Hello</title></head><body><h1>Incorrect Username and password </h1></body><html>);

srout.close();
}
}

form.html

<html>
<head><title>Example program for servlet</title>
<head>

<body>
<form id="frm" action http://localhost:8080/servlet/hello" method="get">

<table>
<tr><td> Username Ad><td><input type="text" id="usertxt"
name "userra" /></td></tr>
Irid Password</td><td><mput type="password" id="passwordtxt"
name "passwordtxt" /></td></tr>
<tr><td><input type="reset" id="txtclear" value="clear" /></td>
<td><mput type="submit" sd-"btal" value="Login" /></td> <tr>
</table>

</form>
</body>

</html>
