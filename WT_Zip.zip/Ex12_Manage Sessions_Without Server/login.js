(function(){
  const msg = () => document.getElementById("msg");
  const visitsKey="VISITS";

  function incrementVisits(){
    let v=parseInt(localStorage.getItem(visitsKey)||"0",10);
    v++; localStorage.setItem(visitsKey,v);
    return v;
  }

  function login(){
    const user=document.getElementById("user").value.trim();
    const pass=document.getElementById("pass").value.trim();
    if(user==="administrator" && pass==="sam"){
      const count=incrementVisits();
      msg().innerHTML=`<h3>Hello, world!</h3><p>Number of visits: ${count}</p>`;
    } else {
      msg().innerHTML="<p style='color:red;'>Incorrect username or password.</p>";
    }
  }

  document.addEventListener("DOMContentLoaded",()=>{
    document.getElementById("loginBtn").addEventListener("click",login);
  });
})();
