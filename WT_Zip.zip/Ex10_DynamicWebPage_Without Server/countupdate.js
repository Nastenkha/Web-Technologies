// countupdate.js
// Mimics the servlet + AJAX behavior using localStorage (per-browser visits).
// Updates the displayed counter every 300ms.

(function() {
  const KEY = 'VISIT_COUNTER';
  const display = () => document.getElementById('visits');

  // Ensure DOM is ready
  function init() {
    // Initialize count if not present
    if (!localStorage.getItem(KEY)) {
      localStorage.setItem(KEY, '0');
    }

    // Increase visits once on page load (like servlet increment on GET)
    incrementCount();

    // Attach reset button handler
    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        localStorage.setItem(KEY, '0');
        updateVisually();
      });
    }

    // Start periodic "AJAX-like" polling to update displayed count
    setInterval(getVisits, 300);
    // initial display
    updateVisually();
  }

  function incrementCount() {
    const current = parseInt(localStorage.getItem(KEY) || '0', 10);
    localStorage.setItem(KEY, String(current + 1));
  }

  // Simulated "POST to servlet" -> here just read from localStorage
  function getVisits() {
    // In real AJAX you'd request server here.
    // We simulate response XML parsing like the original servlet (optional).
    const count = localStorage.getItem(KEY) || '0';
    // Simulate an XML response and parse it (to resemble original code)
    const xmlString = `<?xml version="1.0"?><count>${count}</count>`;
    // parse string into a DOM
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlString, "application/xml");
    // call updater
    updateVisitsFromXML(xml);
  }

  function updateVisitsFromXML(xml) {
    const countNode = xml.documentElement; // <count>
    if (!countNode) return;
    const value = countNode.textContent || '0';
    const el = display();
    if (el) el.textContent = value;
  }

  function updateVisually() {
    const el = display();
    if (el) el.textContent = localStorage.getItem(KEY) || '0';
  }

  // Start when DOM loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
