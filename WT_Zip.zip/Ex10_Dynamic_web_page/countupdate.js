function init() {
    window.setInterval("getvisits()", 300);
}

function getvisits() {
    var con = new XMLHttpRequest();
    con.open("POST", "/counterservlet", true);
    con.onreadystatechange = function () { updatevisits(con); };
    con.send("");
}

function updatevisits(con) {
    if (con.readyState == 4 && con.status == 200) {
        var visits = document.getElementById("visits");
        var count = con.responseXML.documentElement;
        visits.childNodes[0].data = count.childNodes[0].data;
    }
}

